<?php
require("../include/conectar.php");
$identidad=3;
$prove = mysqli_real_escape_string($con, $identidad);
$query = 'SELECT * FROM funcionarios WHERE identidad = "'.$prove.'"';
$result = mysqli_query($con, $query)
or die("Error: ".mysqli_error($con)) ;
while($row = mysqli_fetch_array($result, MYSQL_ASSOC))
{
    echo '<option value="' .$row["idfuncionario"]. '">' .$row["nombrefuncionario"]." ".$row["apellidosfuncionario"]. '</option>';
}
mysqli_close($con);
?>
