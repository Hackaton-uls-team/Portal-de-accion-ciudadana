<html>

<?php
require("../include/conectar.php"); ?>

<?php

//$q = $_POST["q"];
$query = 'SELECT * FROM funcionarios WHERE identidad = 1';
$result = mysqli_query($con, $query)
or die("Error: ".mysqli_error($con)) ;
echo "<select class='selectpicker' data-live-search='true' id='funcionario' name='funcionario' onchange=location.href='consulta.php?entidad='+this.value>";
echo "<option>-Selecciona una entidad-</option>";
while($row = mysqli_fetch_array($result, MYSQL_ASSOC))
{
    echo '<option value="' .$row["idfuncionario"]. '">' .$row["nombrefuncionario"]." ".$row["apellidosfuncionario"]. '</option>';
}
mysqli_close($con);

?>
</select>
</html>
