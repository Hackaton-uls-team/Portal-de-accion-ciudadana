<!DOCTYPE html>
<html lang="en">
<head>
<title>Consulta Ciudadana</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-select.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap-select.min.js"></script>

</head>

<body>
<form class="form-horizontal">
    <div class="container" >
        <div class="col-sm-2">
          <img src="#" alt="..." class="img-responsive" width="200" height="135">
        </div>
        <div class="col-sm-10">
          <h2>Consulta Ciudadana</h2>
        </div>
      </div>
    <div class="container">
       <div class="col-sm-offset-2 col-md-8">
      <form class="form-horizontal" action="/action_page.php">
        <div class="form-group">
            <label class="control-label col-sm-3" for="nombre">Titulo:</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="titulo" placeholder="titulo" name="titulo" required />
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-3" for="funcionario">Seleccione una Entidad:</label>
            <div class="col-sm-9">

            <select class="selectpicker" data-live-search="true" id="entidades" name="entidades" onchange=location.href='consulta.php?entidad='+this.value>
                <option>-Selecciona una entidad-</option>
                <?php
                require('include/conectar.php');
                $query = 'SELECT * FROM entidades';
                $result = mysqli_query($con, $query);
                while($row = mysqli_fetch_array($result, MYSQL_ASSOC))
                {
                  if (isset($_GET['entidad'])){
                    if ($_GET['entidad']==$row['identidad']){
                      echo '<option value="' .$row["identidad"]. '" selected>' .$row["nombreentidad"]. '</option>';
                    }
                    else{
                      echo '<option value="' .$row["identidad"]. '" >' .$row["nombreentidad"]. '</option>';
                    }
                  }
                  else{
                    echo '<option value="' .$row["identidad"]. '">' .$row["nombreentidad"]. '</option>';

                  }
                }
                //mysqli_close($con);
                ?>
            </select>
          </div>
        </div>
        <?php
        if (isset($_GET['entidad'])){
          ?>
        <div class="form-group">
            <div class="col-sm-9" >
              <?php
                $q = $_GET['entidad'];
                $query2 = 'SELECT * FROM funcionarios where identidad='.$q;
                ?>
                <select class='selectpicker' data-live-search='true' id='funcionario' name='funcionario' >
                <option>-Seleccione un Funcionario-</option>
                <?php
                $result = mysqli_query($con, $query2);
                while($row = mysqli_fetch_array($result, MYSQL_ASSOC))
                {
                    echo '<option value="' .$row["idfuncionario"]. '">' .$row["nombrefuncionario"]." ".$row["apellidosfuncionario"]. '</option>';
                }
                mysqli_close($con);
              ?>
            </select>
            </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-3" for="apellidos">Indique el asunto:</label>
          <div class="col-sm-9" >
          <!--  <textarea name="asunto" class="form-control" rows="3" cols="60" placeholder="Maximo 200 caracteres" onkeypress="if(this.value.length>= 200){alert('Has superado el tamaño máximo permitido'); return false;" } ></textarea>
        -->
            <input maxlength="200" >
          </div>

        </div>
      <?php } ?>


  <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Guardar Informacion</button>
          </div>
        </div>
      </form>
      </div>
</div>


<div id="respuesta"></div>
</body>
<footer class="footer" style="background-color: #e3f2fd;" >
      <div class="container" >
        <span class="text-center"></span>
      </div>
    </footer>


</html>
