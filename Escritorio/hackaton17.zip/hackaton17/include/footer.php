<?php
<div  style="background-color:#E6E6FA" class="footer">
  <div class="container-fluid">
<div class="col-md-1"></div><!-- espacio-->
<div class="col-xs-3">
  <div aling="center">
    <p font size="15"  font face ="verdana">
      <center><span id="glyphicon" class="glyphicon glyphicon-console"></center>
      Desarrollado <br>
      Team ULS 1 <br>
      #hackatonsv17
      </p>

  </div>
</div><!--col md 3-->
<div class="col-md-1"></div><!-- espacio-->
<div class="col-xs-3">
  <div aling="center">

    <p font size="15" font face ="verdana">
        <center><span id="glyphicon" class="glyphicon glyphicon-user"></center>
      Porta de Acción Ciudada <br>
      Este portal se ah realizado con el fin de <br>
      poder brindar un espacio para que la poblacion <br>
      pueda realizar sus consultas y obtener una respuesta <br>
      </p>
  </div>
</div><!--col md 3-->
<div class="col-md-1"></div> <!--espacio-->
<div class="col-xs-3">
  <div aling="center">
    <p font size="15" font face ="verdana">
      <center><span id="glyphicon" class="glyphicon glyphicon-eye-open"></center>
      Porta de Acción Ciudada <br>
      Este portal se ah realizado con el fin de <br>
      poder brindar un espacio para que la poblacion <br>
      pueda realizar sus consultas y obtener una respuesta <br>
      </p>

  </div>
</div><!--col md 3-->
</div><!--container fluid-->
<div style="background-color:rgb(18, 50, 121)" class=""> <center> <p style="color:white" > Universidad Luterana de El Salvador</p></center></div>
</div><!--footer-->


 ?>
