<?php
//Indicamos a php que lo que estamos por crear es un archivo XML
header('Content-type: text/xml; charset="unicode-UTF-8"', true);

//y como todo archivo XML debemos definirlo de esta manera:
echo '<?xml version="1.0" encoding="iso-8859-1"?>';

//Aquí la conexión o archivo de conexión a nuestra base de datos
include ("conexion.php");
$link=Conectarse();

// Generamos nuestro documento
echo '
<rss version="2.0" >';

//Hacemos una consulta y la ordenamos por el id para la fecha del chanel
$notc = mysql_query("SELECT * FROM news ORDER BY id DESC LIMIT 1");

//Creamos un while para poder generar la fecha
while($row = mysql_fetch_array($notc)){
echo '
<channel>
  <title>titulo del rss</title>
  <link>url de la web</link>
  <description>corta descripción de la pagina</description>
  <language>es</language>
  <lastBuildDate>'.$row[fecha].'</lastBuildDate>
  <generator>Notepad</generator>
';
}
//Hacemos la consulta y la ordenamos por id para mostrar siempre el último
$resultado=mysql_query("select * from news order by id Desc",$link);

//"Cortaremos" el artículo en 300 caracteres para hacer nuestra descripción
$description=substr($row[descripcion],0,300)."[…]";

//Creamos un while para poder generar todos los extractos de noticias de nuestro sitio
while($row = mysql_fetch_array($resultado)){
echo '  <item>
    <title><![CDATA['.$row[titulo].']]></title>
    <link>'.$row[leer].'</link>
    <pubDate>'.$row[fecha].'</pubDate>
    <description><![CDATA['.$row[descripcion].''.$description.']]></description>
    <category><![CDATA['.$row[tipo].']]></category>
    <guid isPermaLink="true">'.$row[leer].'</guid>
  </item>
';
}
echo'</channel>
</rss>';
?>
