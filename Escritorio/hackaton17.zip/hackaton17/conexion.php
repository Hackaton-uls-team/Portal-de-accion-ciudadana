<?php
function Conectarse()
{  //conectamos a la base
if (!($link=mysql_connect("localhost", "root", "", "prototipo")))
{
echo "Error conectando a la base de datos.";
exit();
}   //Seleccionamos la base
if (!mysql_select_db("prototipo",$link))
{
echo "Error seleccionando la base de datos.";
exit();
}
return $link;
}
?>
