<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/bootstrap-select.min.css">
  <script src="js/bootstrap.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>

        <title>Portal de accion ciudadana </title>
  </head>
  <body>
<!--  <div id="contenedor-fondo" class="container-fluid">
    <div id="navbar" class="navbar navbar-default" role="navigation">
        <div class="navbar-collapse collapse">
            <ul id="uls-menu" class="nav navbar-nav navbar-center">
                <li><a style="color:white" href="#">Center 1</a></li>
                <li><a style="color:white" href="#">Center 2</a></li>
                <li><a style="color:white" href="#">Center 3</a></li>
            </ul>
          </div>
        </div><!--navbar-->
    <div class="container-fluid">


<div id="carousel-example" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example" data-slide-to="1"></li>
    <li data-target="#carousel-example" data-slide-to="2"></li>
    <li data-target="#carousel-example" data-slide-to="3"></li>
  </ol>

  <div class="carousel-inner">
    <div class="item active">
      <a href="#"><img width="100%" src="img/1.png" /></a>
    </div>
    <div class="item">
      <a href="#"><img width="100%" src="img/2.png" /></a>
    </div>
    <div class="item">
      <a href="#"><img width="100%" src="img/3.png" /></a>
    </div>
    <div class="item">
      <a href="#"><img width="100%" src="img/4.png" /></a>
    </div>
  </div>

  <a class="left carousel-control" href="#carousel-example" data-slide="prev">
    <span id="glyphicon" class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
  </div><!--slide-->

</div><!--contenedor-fondo-->

<div class="container-fluid">
  <hr>
<div class="jumbotron">

    <h2>Consulta</h2>
    <div class="container">
       <div class="col-sm-offset-2 col-md-8">
      <form class="form-horizontal" action="/action_page.php">

        <div class="form-group">
            <label class="control-label col-sm-3" for="funcionario">Seleccione una Entidad Gubernamental:</label>
            <div class="col-sm-9">

            <select class="selectpicker" data-live-search="true" id="entidades" name="entidades" onchange=location.href='consultas.php?entidad='+this.value>
                <option>-Selecciona una entidad-</option>
                <?php
                require('include/conectar.php');
                $query = 'SELECT * FROM entidades';
                $result = mysqli_query($con, $query);
                while($row = mysqli_fetch_array($result, MYSQL_ASSOC))
                {
                  if (isset($_GET['entidad'])){
                    if ($_GET['entidad']==$row['identidad']){
                      echo '<option value="' .$row["identidad"]. '" selected>' .$row["nombreentidad"]. '</option>';
                    }
                    else{
                      echo '<option value="' .$row["identidad"]. '" >' .$row["nombreentidad"]. '</option>';
                    }
                  }
                  else{
                    echo '<option value="' .$row["identidad"]. '">' .$row["nombreentidad"]. '</option>';

                  }
                }
                //mysqli_close($con);
                ?>
            </select>
          </div>
        </div>
        <?php
        if (isset($_GET['entidad'])){
          ?>
        <div class="form-group">
              <label class="control-label col-sm-3" for="funcionario">Seleccione un Funcionario:</label>
            <div class="col-sm-9" >
              <?php
                $q = $_GET['entidad'];
                $query2 = 'SELECT * FROM funcionarios where identidad='.$q;
                ?>
                <select class='selectpicker' data-live-search='true' id='funcionario' name='funcionario' >
                <option>-Seleccione un Funcionario-</option>
                <?php
                $result = mysqli_query($con, $query2);
                while($row = mysqli_fetch_array($result, MYSQL_ASSOC))
                {
                    echo '<option value="' .$row["idfuncionario"]. '">' .$row["nombrefuncionario"]." ".$row["apellidosfuncionario"]. '</option>';
                }
                mysqli_close($con);
              ?>
            </select>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-3" for="nombre">Asunto:</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="asunto" placeholder="Asunto" name="asunto" required />
            </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-3" for="apellidos">Indique la descripci&oacute;n:</label>

            <textarea  required rows="3" class="col-sm-9"></textarea>
          <!--  <input type="text" class="form-control" id="descripcion" placeholder="Descripcion de la solicitud" name="descripcion" required />
        -->
        <br>
        <h3>Datos del Ciudadano</h3>
        </div>
            <div class="form-group">
            <label class="control-label col-sm-3" for="nombre">Nombre Completo:</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="nombre" placeholder="Nombres y Apellidos seg&uacute;n DUI" name="nombre" required />
            </div>
            </div>
              <div class="form-group">
            <label class="control-label col-sm-3" for="dui">DUI:</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="dui" placeholder="0000000-0" name="dui" required />
            </div>
            </div>
            <div class="form-group">
            <label class="control-label col-sm-3" for="telefono">Telefono:</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="telefono" placeholder="00000000" name="telefono" required />
            </div>
          </div>
            <div class="form-group">
            <label class="control-label col-sm-3" for="celular">Celular:</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="celular" placeholder="00000000" name="celular" required />
            </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-3" for="nombre">Correo:</label>
              <div class="col-sm-9">
                  <input type="text" class="form-control" id="correo" placeholder="ejemplo@dominio.com" name="correo" required />
              </div>
            </div>-
            <div class="form-group">
                 <label class="control-label col-sm-3" for="funcionario">Forma de Notificacion:</label>
               <div class="col-sm-9" >
                 <select id="cmbNoti" name="cmbNoti" onchange="document.getElementById('selected_text').value=this.options[this.selectedIndex].text">
                   <option class="control-label" for="funcionario" value="0">Seleccione forma de Notificacion</option>
                   <option value="1">Telegram</option>
                   <option value="2">WhatsApp</option>
                   <option value="3">Messenger</option>
                   <option value="1">Email</option>
                   <option value="2">SMS</option>
                 </select>
             </div>
           </div>

      <?php } ?>
      <div class="form-group">
              <div class="col-sm-offset-3 col-sm-9 ">
                <button type="submit" class="btn btn-primary btn-lg">Enviar Informacion</button>
              </div>
            </div>
          </form>
          </div>
      </div>
</div>
</div>
<div  style="background-color:#E6E6FA" class="footer">
  <div class="container-fluid">
<div class="col-md-1"></div><!-- espacio-->
<div class="col-xs-3">
  <div aling="center">
    <p font size="15"  font face ="verdana">
      <center><span id="glyphicon" class="glyphicon glyphicon-console"></center>
      Desarrollado <br>
      Team ULS 1 <br>
      #hackatonsv17
      </p>

  </div>
</div><!--col md 3-->
<div class="col-md-1"></div><!-- espacio-->
<div class="col-xs-3">
  <div aling="center">

    <p font size="15" font face ="verdana">
        <center><span id="glyphicon" class="glyphicon glyphicon-user"></center>
      Porta de Acción Ciudada <br>
      Este portal se ha realizado con el fin de <br>
      poder brindar un espacio para que la poblaci&oacute;n <br>
      pueda realizar sus consultas y obtener una respuesta <br>
      </p>
  </div>
</div><!--col md 3-->
<div class="col-md-1"></div> <!--espacio-->
<div class="col-xs-3">
  <div aling="center">
    <p font size="15" font face ="verdana">
      <center><span id="glyphicon" class="glyphicon glyphicon-eye-open"></center>
      Porta de Acción Ciudada <br>
      Este portal se ah realizado con el fin de <br>
      poder brindar un espacio para que la poblaci&oacute;n <br>
      pueda realizar sus consultas y obtener una respuesta <br>
      </p>

  </div>
</div><!--col md 3-->
</div><!--container fluid-->
<div style="background-color:rgb(18, 50, 121)" class=""> <center> <p style="color:white" > Universidad Luterana de El Salvador</p></center></div>
</div><!--footer-->

</body>
</html>
