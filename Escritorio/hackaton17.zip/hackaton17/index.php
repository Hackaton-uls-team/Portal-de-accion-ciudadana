<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/nav.css">

  <script src="js/bootstrap.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="img/loco.png" />
        <title>Portal de accion ciudadana </title>
  </head>
  <body>
  <!--
 <div id="contenedor-fondo" class="container-fluid">
    <div id="navbar" class="navbar navbar-default" role="navigation">
      <div class="col-md-1"> </div>
      <img id="logo" width="75px" height="75px" src="img/loco.png">
    </div>

    <div class="navbar-collapse collapse">
            <ul id="uls-menu" class="nav navbar-nav navbar-center">
                <li><a style="color:white" href="#">CONSULTA CIUDADANA</a></li>

            </ul>
          </div>
        </div><!--navbar-->
    <div class="container-fluid">


<div id="carousel-example" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example" data-slide-to="1"></li>
    <li data-target="#carousel-example" data-slide-to="2"></li>
    <li data-target="#carousel-example" data-slide-to="3"></li>
  </ol>

  <div class="carousel-inner">
    <div class="item active">
      <a href="#"><img width="100%" src="img/1.png" /></a>
    </div>
    <div class="item">
      <a href="#"><img width="100%" src="img/2.png" /></a>
    </div>
    <div class="item">
      <a href="#"><img width="100%" src="img/3.png" /></a>
    </div>
    <div class="item">
      <a href="#"><img width="100%" src="img/4.png" /></a>
    </div>
  </div>

  <a class="left carousel-control" href="#carousel-example" data-slide="prev">
    <span id="glyphicon" class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
    </div><!--slide-->
    <div class="container">
        <div class="col-md-1">
            <img width="75px" height="75px" src="img/logo.png" ></img>
          </div>
          <div class="col-md-6">
            <h1>Portal de Acción Ciudadana</h1> <br>
            <p><h3>Participa y resuelves tus dudas</h3></p>
          </div>
          <div class="col-md-12">
              <p>Participa, Pregunta, y </p>
          </div>
          <div class="col-md-12">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum..</p>
            <p>This is another text.</p>

          </div>
    </div><!--container-->
</div><!--contenedor-fondo-->

<div class="container-fluid">
<div class="jumbotron">
  <center>
    <h2>Consulta</h2>
    <div class="form-group">
      <a  class=" col-md-12 btn btn-warning btn-lg" href="consultas.php">Realizar Consulta</a>

    </div>
    </center>

</div>
</div>
<div  style="background-color:#E6E6FA" class="footer">
  <div class="container-fluid">
<div class="col-md-1"></div><!-- espacio-->
<div class="col-xs-3">
  <div aling="center">
    <p font size="15"  font face ="verdana">
      <center><span id="glyphicon" class="glyphicon glyphicon-console"></center>
      Desarrollado <br>
      Team ULS 1 <br>
      #hackatonsv17
      </p>

  </div>
</div><!--col md 3-->
<div class="col-md-1"></div><!-- espacio-->
<div class="col-xs-3">
  <div aling="center">

    <p font size="15" font face ="verdana">
        <center><span id="glyphicon" class="glyphicon glyphicon-user"></center>
      Porta de Acción Ciudada <br>
      Este portal se ah realizado con el fin de <br>
      poder brindar un espacio para que la poblacion <br>
      pueda realizar sus consultas y obtener una respuesta <br>
      </p>
  </div>
</div><!--col md 3-->
<div class="col-md-1"></div> <!--espacio-->
<div class="col-xs-3">
  <div aling="center">
    <p font size="15" font face ="verdana">
      <center><span id="glyphicon" class="glyphicon glyphicon-eye-open"></center>
      Porta de Acción Ciudada <br>
      Este portal se ah realizado con el fin de <br>
      poder brindar un espacio para que la poblacion <br>
      pueda realizar sus consultas y obtener una respuesta <br>
      </p>

  </div>
</div><!--col md 3-->
</div><!--container fluid-->
<div style="background-color:rgb(18, 50, 121)" class=""> <center> <p style="color:white" > Universidad Luterana de El Salvador</p></center></div>
</div><!--footer-->

</body>
</html>
